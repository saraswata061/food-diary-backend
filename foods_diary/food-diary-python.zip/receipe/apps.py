from django.apps import AppConfig


class ReceipeConfig(AppConfig):
    name = 'receipe'
