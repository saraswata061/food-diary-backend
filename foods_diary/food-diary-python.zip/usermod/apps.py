from django.apps import AppConfig


class UsermodConfig(AppConfig):
    name = 'usermod'
